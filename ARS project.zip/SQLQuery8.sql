/****** Script for SelectTopNRows command from SSMS  ******/
SELECT TOP (1000) [ID]
      ,[Username]
      ,[Password]
  FROM [ARS].[dbo].[ADMIN]

 "Airport_ID";
 "Airport_Name";
 "City";
 "Country";