/****** Script for SelectTopNRows command from SSMS  ******/
SELECT TOP (1000) [Airline_ID]
      ,[Airline_Name]
      ,[Airplanes]
  FROM [ARS].[dbo].[Airline]

  First_Name, Last_Name, Admin_ID, Username, Admin_Password, Email, Contact, Admin_Address