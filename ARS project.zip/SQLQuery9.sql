insert into Airport (Airport_Name,City,Country)values('Allama Iqbal International Airport','Lahore','Pakistan')
Select*from Airport